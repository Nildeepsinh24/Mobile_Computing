package com.bca2021.gridviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IndiaActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_india2);
    }
}