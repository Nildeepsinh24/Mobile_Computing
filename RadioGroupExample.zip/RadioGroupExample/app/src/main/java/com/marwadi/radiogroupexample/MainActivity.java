package com.marwadi.radiogroupexample;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg;
    RadioButton r_ind,r_aus,r_fiji,r_can,r_afg,r_ice,r_israel,r_jap;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg = findViewById(R.id.rg);
        r_ind = findViewById(R.id.r_ind);
        r_aus = findViewById(R.id.r_aus);
        r_fiji = findViewById(R.id.r_fiji);
        r_can = findViewById(R.id.r_can);
        r_ice = findViewById(R.id.r_ice);
        r_afg = findViewById(R.id.r_afg);
        r_israel = findViewById(R.id.r_israel);
        r_jap = findViewById(R.id.r_jap);


        img = findViewById(R.id.img);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (r_ind.isChecked()){
                    img.setImageResource(R.drawable.india);
                }
                else if (r_aus.isChecked()){
                    img.setImageResource(R.drawable.australia);
                }
                else if (r_fiji.isChecked()){
                    img.setImageResource(R.drawable.fiji);
                }
                else if (r_can.isChecked()){
                    img.setImageResource(R.drawable.canada);
                }

                else if (r_ice.isChecked()){
                    img.setImageResource(R.drawable.iceland);
                }

                else if (r_afg.isChecked()){
                    img.setImageResource(R.drawable.afghanistan);
                }

                else if (r_israel.isChecked()){
                    img.setImageResource(R.drawable.israel);
                }

                else if (r_jap.isChecked()){
                    img.setImageResource(R.drawable.japan);
                }

            }
        });

    }
}